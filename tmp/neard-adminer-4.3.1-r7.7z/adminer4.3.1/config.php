<?php

global $mysqlPort, $mysqlRootUser, $mysqlRootPwd,
$mariadbPort, $mariadbRootUser, $mariadbRootPwd,
$postgresqlPort, $postgresqlRootUser, $postgresqlRootPwd,
$mongodbPort;

$mysqlPort = 3306;
$mysqlRootUser = 'root';
$mysqlRootPwd = '';

$mariadbPort = 3307;
$mariadbRootUser = 'root';
$mariadbRootPwd = '';

$postgresqlPort = 5432;
$postgresqlRootUser = 'postgres';
$postgresqlRootPwd = '';

$mongodbPort = 27017;
